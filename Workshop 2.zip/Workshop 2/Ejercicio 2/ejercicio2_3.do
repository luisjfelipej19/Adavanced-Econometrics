*******************************************************
* Taller Econometría - Ejercicio 2 - Gráficos 
* Luis Felipe Gaviria Gil - Luis Felipe Jiménez Sánchez
* Requiere: female_politics.dta en la misma carpeta
*******************************************************

version 18
clear all
set more off
capture log close
set scheme s2color

log using "punto3_rd_graph_mejorado.log", replace text

*******************************************************
* 0. Cargar base
*******************************************************
use "female_politics.dta", clear

*******************************************************
* 1. Verificaciones básicas //Hecho por chatgpt para hacer verificación
*******************************************************
capture confirm variable PrimMargin
if _rc {
    di as error "No existe la variable PrimMargin"
    exit 198
}

capture confirm variable GenWin
if _rc {
    di as error "No existe la variable GenWin"
    exit 198
}

capture confirm variable primary_winner
if _rc {
    di as error "No existe la variable primary_winner"
    exit 198
}

drop if missing(PrimMargin, GenWin, primary_winner)

*******************************************************
* 2. Parámetros del gráfico
*    - ventana solo para visualización
*    - bins para promedios
*******************************************************
local xmax = 0.80
local binw = 0.02

keep if abs(PrimMargin) <= `xmax'

*******************************************************
* 3. Construcción de bins
*******************************************************
gen bin = floor((PrimMargin + `xmax') / `binw')
bysort bin: egen mean_GenWin     = mean(GenWin)
bysort bin: egen mean_PrimMargin = mean(PrimMargin)
egen tagbin = tag(bin)

*******************************************************

*******************************************************
* Ajuste lineal por lado
*******************************************************
reg GenWin PrimMargin if PrimMargin < 0
predict yhat_linear_left if e(sample)

reg GenWin PrimMargin if PrimMargin >= 0
predict yhat_linear_right if e(sample)

twoway ///
    (scatter mean_GenWin mean_PrimMargin if tagbin & mean_PrimMargin < 0, ///
        msymbol(Oh) msize(medlarge) mcolor(gs7)) ///
    (scatter mean_GenWin mean_PrimMargin if tagbin & mean_PrimMargin >= 0, ///
        msymbol(Oh) msize(medlarge) mcolor(navy)) ///
    (line yhat_linear_left PrimMargin if PrimMargin < 0, ///
        sort lcolor(black) lwidth(medthick)) ///
    (line yhat_linear_right PrimMargin if PrimMargin >= 0, ///
        sort lcolor(navy) lwidth(medthick)) ///
    , ///
    xline(0, lpattern(dash) lcolor(maroon) lwidth(medthin)) ///
    xlabel(-0.80(0.10)0.80, format(%4.2f) labsize(medsmall) angle(0)) ///
    ylabel(0(0.1)1, angle(horizontal) labsize(medsmall)) ///
    xscale(range(-`xmax' `xmax')) ///
    yscale(range(0 0.005)) ///
    xtitle("Margen en primaria (PrimMargin)", size(medium)) ///
    ytitle("Probabilidad de ganar la general (GenWin)", size(medium)) ///
    title("RD: ajuste lineal por lado", size(large)) ///
    subtitle("Promedios por bins + polinomio global grado 1", size(medsmall)) ///
    legend(order(1 "Bins: izquierda" 2 "Bins: derecha" 3 "Lineal: izquierda" 4 "Lineal: derecha") ///
           rows(2) position(6) ring(0) region(lstyle(none)) size(small)) ///
    graphregion(color(white)) ///
    plotregion(color(white)) ///
    note("Ventana de visualización: |PrimMargin| <= `xmax'; ancho de bin = `binw'", size(vsmall)) ///
    name(rd_linear, replace)

graph export "rd_linear.png", width(2400) replace
graph save   "rd_linear.gph", replace

*******************************************************
* 4. Gráfico RD cuadrático
*******************************************************
twoway ///
    (scatter mean_GenWin mean_PrimMargin if tagbin & mean_PrimMargin < 0, ///
        msymbol(Oh) msize(medlarge) mcolor(gs7)) ///
    (scatter mean_GenWin mean_PrimMargin if tagbin & mean_PrimMargin >= 0, ///
        msymbol(Oh) msize(medlarge) mcolor(navy)) ///
    (qfit GenWin PrimMargin if PrimMargin < 0, ///
        lcolor(black) lwidth(medthick)) ///
    (qfit GenWin PrimMargin if PrimMargin >= 0, ///
        lcolor(navy) lwidth(medthick)) ///
    , ///
    xline(0, lpattern(dash) lcolor(maroon) lwidth(medthin)) ///
    xlabel(-0.80(0.2)0.80, format(%4.2f) labsize(medsmall)) ///
    ylabel(0(0.05)1, angle(horizontal) labsize(medsmall)) ///
    xscale(range(-`xmax' `xmax')) ///
    yscale(range(0 1)) ///
    xtitle("Margen en primaria (PrimMargin)", size(medium)) ///
    ytitle("Probabilidad de ganar la general (GenWin)", size(medium)) ///
    title("Diseño RD: GenWin vs PrimMargin", size(large)) ///
    subtitle("Promedios por bins y polinomio global cuadrático por lado", size(medsmall)) ///
    legend(order(1 "Bins: izquierda del corte" ///
                 2 "Bins: derecha del corte" ///
                 3 "Ajuste cuadrático: izquierda" ///
                 4 "Ajuste cuadrático: derecha") ///
           rows(2) position(6) ring(0) region(lstyle(none)) size(small)) ///
    note("Ventana de visualización: |PrimMargin| <= `xmax'; ancho de bin = `binw'", size(vsmall)) ///
    graphregion(color(white)) ///
    plotregion(color(white)) ///
    name(rd_genwin_quad_bonito, replace)

*******************************************************
* 5. Exportar
*******************************************************
graph export "rd_genwin_quad_bonito.png", width(2400) replace
graph save   "rd_genwin_quad_bonito.gph", replace


**Polinomios mayores cúbico y cuartico

*******************************************************
* 4. Crear potencias de PrimMargin
*******************************************************
gen pm2 = PrimMargin^2
gen pm3 = PrimMargin^3
gen pm4 = PrimMargin^4

sort PrimMargin

*******************************************************
* 5. Ajuste cúbico por lado
*******************************************************
reg GenWin PrimMargin pm2 pm3 if PrimMargin < 0
predict yhat_cubic_left if e(sample)

reg GenWin PrimMargin pm2 pm3 if PrimMargin >= 0
predict yhat_cubic_right if e(sample)

twoway ///
    (scatter mean_GenWin mean_PrimMargin if tagbin & mean_PrimMargin < 0, ///
        msymbol(Oh) msize(medlarge) mcolor(gs7)) ///
    (scatter mean_GenWin mean_PrimMargin if tagbin & mean_PrimMargin >= 0, ///
        msymbol(Oh) msize(medlarge) mcolor(navy)) ///
    (line yhat_cubic_left PrimMargin if PrimMargin < 0, ///
        sort lcolor(black) lwidth(medthick)) ///
    (line yhat_cubic_right PrimMargin if PrimMargin >= 0, ///
        sort lcolor(navy) lwidth(medthick)) ///
    , ///
    xline(0, lpattern(dash) lcolor(maroon) lwidth(medthin)) ///
    xlabel(-0.80(0.20)0.80, format(%4.2f) labsize(medsmall)) ///
    ylabel(0(0.05)1, angle(horizontal) labsize(medsmall)) ///
    xscale(range(-`xmax' `xmax')) ///
    yscale(range(0 1)) ///
    xtitle("Margen en primaria (PrimMargin)", size(medium)) ///
    ytitle("Probabilidad de ganar la general (GenWin)", size(medium)) ///
    title("RD: ajuste cúbico por lado", size(large)) ///
    subtitle("Promedios por bins + polinomio global grado 3", size(medsmall)) ///
    legend(order(1 "Bins: izquierda" 2 "Bins: derecha" 3 "Cúbico: izquierda" 4 "Cúbico: derecha") ///
           rows(2) position(6) ring(0) region(lstyle(none)) size(small)) ///
    graphregion(color(white)) ///
    plotregion(color(white)) ///
    name(rd_cubic, replace)

graph export "rd_cubic.png", width(2400) replace
graph save   "rd_cubic.gph", replace

*******************************************************
* 6. Ajuste cuártico por lado
*******************************************************
reg GenWin PrimMargin pm2 pm3 pm4 if PrimMargin < 0
predict yhat_quartic_left if e(sample)

reg GenWin PrimMargin pm2 pm3 pm4 if PrimMargin >= 0
predict yhat_quartic_right if e(sample)

twoway ///
    (scatter mean_GenWin mean_PrimMargin if tagbin & mean_PrimMargin < 0, ///
        msymbol(Oh) msize(medlarge) mcolor(gs7)) ///
    (scatter mean_GenWin mean_PrimMargin if tagbin & mean_PrimMargin >= 0, ///
        msymbol(Oh) msize(medlarge) mcolor(navy)) ///
    (line yhat_quartic_left PrimMargin if PrimMargin < 0, ///
        sort lcolor(black) lwidth(medthick)) ///
    (line yhat_quartic_right PrimMargin if PrimMargin >= 0, ///
        sort lcolor(navy) lwidth(medthick)) ///
    , ///
    xline(0, lpattern(dash) lcolor(maroon) lwidth(medthin)) ///
    xlabel(-0.80(0.10)0.80, format(%4.2f) labsize(medsmall)) ///
    ylabel(0(0.05)1, angle(horizontal) labsize(medsmall)) ///
    xscale(range(-`xmax' `xmax')) ///
    yscale(range(0 1)) ///
    xtitle("Margen en primaria (PrimMargin)", size(medium)) ///
    ytitle("Probabilidad de ganar la general (GenWin)", size(medium)) ///
    title("RD: ajuste cuártico por lado", size(large)) ///
    subtitle("Promedios por bins + polinomio global grado 4", size(medsmall)) ///
    legend(order(1 "Bins: izquierda" 2 "Bins: derecha" 3 "Cuártico: izquierda" 4 "Cuártico: derecha") ///
           rows(2) position(6) ring(0) region(lstyle(none)) size(small)) ///
    graphregion(color(white)) ///
    plotregion(color(white)) ///
    name(rd_quartic, replace)

graph export "rd_quartic.png", width(2400) replace
graph save   "rd_quartic.gph", replace


log close
*******************************************************
* Fin
*******************************************************