*******************************************************
* Taller 3
* Luis Felipe Gaviria Gil - Luis Felipe Jiménez Sánchez
* Ejercicio 3 - RD lineal local y ajuste cuadrático
* Requiere: female_politics.dta en la misma carpeta
*******************************************************

version 18
clear all
set more off
capture log close

*---------------------------------------------*
* 0. Instalar estout si no está disponible
*---------------------------------------------*
capture which esttab
if _rc ssc install estout, replace

capture which eststo
if _rc ssc install estout, replace

capture which estadd
if _rc ssc install estout, replace

log using "punto4_lineal_local.log", replace text

*---------------------------------------------*
* 1. Cargar base
*---------------------------------------------*
use "female_politics.dta", clear

*---------------------------------------------*
* 2. Verificaciones básicas //Hecho por chatgpt para verificación
*---------------------------------------------*
capture confirm variable GenWin
if _rc {
    di as error "No existe la variable GenWin"
    exit 198
}

capture confirm variable PrimMargin
if _rc {
    di as error "No existe la variable PrimMargin"
    exit 198
}

capture confirm variable primary_winner
if _rc {
    di as error "No existe la variable primary_winner"
    exit 198
}

drop if missing(GenWin, PrimMargin, primary_winner)

*---------------------------------------------*
* 3. Variables para RD lineal local
*---------------------------------------------*
gen D  = primary_winner
gen z  = PrimMargin
gen Dz = D*z

* Comprobación de consistencia básica del RD nítido //Hecho por ChatGpt para automatizar verificación
capture assert D == (z > 0) if z != 0
if _rc {
    di as error "Advertencia: primary_winner no coincide perfectamente con el signo de PrimMargin."
    di as error "Revise si hay empates, recodificaciones o inconsistencias."
}

*---------------------------------------------*
* 4. Controles
*  
*---------------------------------------------*
global ctrls "dem inc PrezYear Y82to90 Y92to00 Y02to10" //justificación de inclusión dentro del texto del taller

*---------------------------------------------*
* 5. Estimaciones
*---------------------------------------------*
eststo clear

* (1) BW = 0.15, sin controles
eststo m1: reg GenWin D z Dz if abs(z) <= 0.15, vce(robust)
estadd local Controls "No"
estadd local BW "0.15"

* (2) BW = 0.15, con controles
eststo m2: reg GenWin D z Dz $ctrls if abs(z) <= 0.15, vce(robust)
estadd local Controls "Sí"
estadd local BW "0.15"

* (3) BW = 0.10, con controles
eststo m3: reg GenWin D z Dz $ctrls if abs(z) <= 0.10, vce(robust)
estadd local Controls "Sí"
estadd local BW "0.10"

* (4) BW = 0.05, con controles
eststo m4: reg GenWin D z Dz $ctrls if abs(z) <= 0.05, vce(robust)
estadd local Controls "Sí"
estadd local BW "0.05"

*---------------------------------------------*
* 6. Tabla /Hecha por chatgpt para hacer una impresión limpia 
*---------------------------------------------*
esttab m1 m2 m3 m4 using "tabla_rd_lineal_local.rtf", replace ///
    b(%9.3f) se(%9.3f) ///
    star(* 0.10 ** 0.05 *** 0.01) ///
    mtitles("(1) BW=0.15" "(2) BW=0.15 + ctrls" "(3) BW=0.10 + ctrls" "(4) BW=0.05 + ctrls") ///
    keep(D z Dz) ///
    order(D z Dz) ///
    coeflabels( ///
        D  "Ganó primaria (salto en 0)" ///
        z  "PrimMargin" ///
        Dz "Ganó primaria × PrimMargin" ///
    ) ///
    stats(N r2 Controls BW, ///
        fmt(0 3 0 0) ///
        labels("Observaciones" "R-cuadrado" "Controles" "Bandwidth")) ///
    title("Diseño RD lineal local: efecto de ganar la primaria sobre GenWin") ///
    addnotes("Errores estándar robustos entre paréntesis.", ///
             "La variable 'Ganó primaria (salto en 0)' es la discontinuidad en el punto de corte.", ///
             "Controles: dem, inc, PrezYear, Y82to90, Y92to00, Y02to10.")

* También mostrar tabla en la ventana de resultados
esttab m1 m2 m3 m4, ///
    b(%9.3f) se(%9.3f) ///
    star(* 0.10 ** 0.05 *** 0.01) ///
    mtitles("(1) BW=0.15" "(2) BW=0.15 + ctrls" "(3) BW=0.10 + ctrls" "(4) BW=0.05 + ctrls") ///
    keep(D z Dz) ///
    order(D z Dz) ///
    coeflabels( ///
        D  "Ganó primaria (salto en 0)" ///
        z  "PrimMargin" ///
        Dz "Ganó primaria × PrimMargin" ///
    ) ///
    stats(N r2 Controls BW, ///
        fmt(0 3 0 0) ///
        labels("Observaciones" "R-cuadrado" "Controles" "Bandwidth"))


*---------------------------------------------*
* 6. Exportar tabla a Word  //hecho por chatgpt para exportar
*---------------------------------------------*
esttab m1 m2 m3 m4 using "tabla_rd_lineal_local.rtf", replace ///
    b(%9.3f) se(%9.3f) ///
    star(* 0.10 ** 0.05 *** 0.01) ///
    mtitles("(1) BW=0.15" "(2) BW=0.15 + ctrls" "(3) BW=0.10 + ctrls" "(4) BW=0.05 + ctrls") ///
    keep(D z Dz) ///
    order(D z Dz) ///
    coeflabels( ///
        D  "Ganó primaria (salto en 0)" ///
        z  "PrimMargin" ///
        Dz "Ganó primaria × PrimMargin" ///
    ) ///
    stats(N r2 Controls BW, ///
        fmt(0 3 0 0) ///
        labels("Observaciones" "R-cuadrado" "Controles" "Bandwidth")) ///
    title("Diseño RD lineal local: efecto de ganar la primaria sobre GenWin") ///
    addnotes("Errores estándar robustos entre paréntesis.", ///
             "La variable 'Ganó primaria (salto en 0)' es la discontinuidad en el punto de corte.", ///
             "Controles: dem, inc, PrezYear, Y82to90, Y92to00, Y02to10.")
			 

			 
*=====================================================*
* 7. RD con polinomio global de grado 2
*=====================================================*

* Crear término cuadrático
capture drop z2 Dz2
gen z2  = z^2
gen Dz2 = D*z2

eststo clear

* (1) Polinomio global grado 2, sin controles
eststo q1: reg GenWin D z z2 Dz Dz2, vce(robust)
estadd local Controls "No"
estadd local Poly "2"

* (2) Polinomio global grado 2, con controles
eststo q2: reg GenWin D z z2 Dz Dz2 $ctrls, vce(robust)
estadd local Controls "Sí"
estadd local Poly "2"

*---------------------------------------------*
* 8. Exportar tabla a Word  //hecho por chatgpt para exportar
*---------------------------------------------*
esttab q1 q2 using "tabla_rd_polinomio2_global.rtf", replace ///
    b(%9.3f) se(%9.3f) ///
    star(* 0.10 ** 0.05 *** 0.01) ///
    mtitles("(1) Sin controles" "(2) Con controles") ///
    keep(D z z2 Dz Dz2) ///
    order(D z z2 Dz Dz2) ///
    coeflabels( ///
        D   "Ganó primaria (salto en 0)" ///
        z   "PrimMargin" ///
        z2  "PrimMargin^2" ///
        Dz  "Ganó primaria × PrimMargin" ///
        Dz2 "Ganó primaria × PrimMargin^2" ///
    ) ///
    stats(N r2 Controls Poly, ///
        fmt(0 3 0 0) ///
        labels("Observaciones" "R-cuadrado" "Controles" "Grado del polinomio")) ///
    title("Diseño RD con polinomio global de grado 2: efecto de ganar la primaria sobre GenWin") ///
    addnotes("Errores estándar robustos entre paréntesis.", ///
             "La variable 'Ganó primaria (salto en 0)' corresponde a la discontinuidad en el punto de corte.", ///
             "Controles: dem, inc, PrezYear, Y82to90, Y92to00, Y02to10.")

* Mostrar también en pantalla
esttab q1 q2, ///
    b(%9.3f) se(%9.3f) ///
    star(* 0.10 ** 0.05 *** 0.01) ///
    mtitles("(1) Sin controles" "(2) Con controles") ///
    keep(D z z2 Dz Dz2) ///
    order(D z z2 Dz Dz2) ///
    coeflabels( ///
        D   "Ganó primaria (salto en 0)" ///
        z   "PrimMargin" ///
        z2  "PrimMargin^2" ///
        Dz  "Ganó primaria × PrimMargin" ///
        Dz2 "Ganó primaria × PrimMargin^2" ///
    ) ///
    stats(N r2 Controls Poly, ///
        fmt(0 3 0 0) ///
        labels("Observaciones" "R-cuadrado" "Controles" "Grado del polinomio"))
		
		
log close
*******************************************************
* Fin
*******************************************************