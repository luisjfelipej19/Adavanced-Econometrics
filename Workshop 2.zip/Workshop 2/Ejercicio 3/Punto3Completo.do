*******************************************************
* Taller Econometría - Ejercicio 3 completo
* Luis Felipe Gaviria Gil - Luis Felipe Jiménez Sánchez
* Requiere: valmoria1989.dta en la misma carpeta
*******************************************************
version 18
clear all
set more off

****************************************************
* 0. Verificar base //Hecho por chatgpt para automatizar apertura
****************************************************
capture confirm file "Valmoria1989.dta"
if _rc {
    di as error "No encuentro Valmoria1989.dta en la carpeta actual."
    di as error "Directorio actual: `c(pwd)'"
    exit 601
}

cap mkdir output

****************************************************
* 1. Cargar base
****************************************************
use "Valmoria1989.dta", clear

****************************************************
* 2. Etiquetas
****************************************************
capture label define zlbl 0 "Sin acceso" 1 "Con acceso", replace
capture label values Z zlbl

label var Y      "Apoyo al régimen"
label var D      "Ve TV de Kuran"
label var age    "Edad"
label var female "Mujer"
label var educ   "Educación"
label var urban  "Urbano"
label var Z      "Acceso técnico a la señal"

****************************************************
* 3. Construir dataset auxiliar para la tabla //Hecho por chatgpt para construir estructura de dataset
****************************************************
tempfile tabla_desc
tempname memhold

postfile `memhold' ///
    str35 variable ///
    str30 con_acceso ///
    str30 sin_acceso ///
    str30 total ///
    str30 diferencia ///
    using `tabla_desc', replace

foreach v in Y D age female educ urban {

    quietly summarize `v' if Z == 1
    local m1  = r(mean)
    local sd1 = r(sd)
    local n1  = r(N)

    quietly summarize `v' if Z == 0
    local m0  = r(mean)
    local sd0 = r(sd)
    local n0  = r(N)

    quietly summarize `v'
    local mt  = r(mean)
    local sdt = r(sd)
    local nt  = r(N)

    quietly ttest `v', by(Z)
    local p = r(p)

    local diff = `m1' - `m0'

    local stars ""
    if `p' < 0.10 local stars "*"
    if `p' < 0.05 local stars "**"
    if `p' < 0.01 local stars "***"

    * celdas principales: media (sd) [N]
    local cell1 = string(`m1', "%9.3f") + " (" + ///
                  string(`sd1', "%9.3f") + ") [" + ///
                  string(`n1', "%9.0f") + "]"

    local cell0 = string(`m0', "%9.3f") + " (" + ///
                  string(`sd0', "%9.3f") + ") [" + ///
                  string(`n0', "%9.0f") + "]"

    local cellt = string(`mt', "%9.3f") + " (" + ///
                  string(`sdt', "%9.3f") + ") [" + ///
                  string(`nt', "%9.0f") + "]"

    * última columna: diferencia + significancia + p-valor
    local celld = string(`diff', "%9.3f") + "`stars'" + ///
                  " [p=" + string(`p', "%9.3f") + "]"

    local nombre "`v'"
    if "`v'" == "Y"      local nombre "Apoyo al régimen (Y)"
    if "`v'" == "D"      local nombre "Ve TV de Kuran (D)"
    if "`v'" == "age"    local nombre "Edad"
    if "`v'" == "female" local nombre "Mujer"
    if "`v'" == "educ"   local nombre "Educación"
    if "`v'" == "urban"  local nombre "Urbano"

    post `memhold' ///
        ("`nombre'") ///
        ("`cell1'") ///
        ("`cell0'") ///
        ("`cellt'") ///
        ("`celld'")
}

postclose `memhold'

****************************************************
* 4. Exportar tabla  //Hecho por chatgpt para exportar tabla lista para colocar en texto
****************************************************
preserve
use `tabla_desc', clear

putdocx clear
putdocx begin, pagesize(letter) font("Times New Roman", 11)

* Título
putdocx paragraph, halign(center)
putdocx text ("Tabla 1. Estadísticas descriptivas por acceso a la señal"), ///
    bold font("Times New Roman", 12)

putdocx paragraph, halign(center)
putdocx text ("Valmoria, 1989"), italic font("Times New Roman", 11)

putdocx paragraph
putdocx text ("")

* Crear tabla en Word: 1 fila encabezado + 6 filas de variables
putdocx table tabla1 = (7,5), width(100%) layout(autofitcontents)

* Encabezados
putdocx table tabla1(1,1) = ("Variable")
putdocx table tabla1(1,2) = ("Con acceso")
putdocx table tabla1(1,3) = ("Sin acceso")
putdocx table tabla1(1,4) = ("Total")
putdocx table tabla1(1,5) = ("Diferencia")

* Estilo encabezado
putdocx table tabla1(1,.), bold halign(center) shading("D9EAF7")
putdocx table tabla1(1,.), border(top, single, black) ///
                           border(bottom, single, black)

* Llenar filas
forvalues i = 1/6 {
    local r = `i' + 1

    putdocx table tabla1(`r',1) = (variable[`i'])
    putdocx table tabla1(`r',2) = (con_acceso[`i'])
    putdocx table tabla1(`r',3) = (sin_acceso[`i'])
    putdocx table tabla1(`r',4) = (total[`i'])
    putdocx table tabla1(`r',5) = (diferencia[`i'])
}

* Formato general
putdocx table tabla1(.,1), halign(left)
putdocx table tabla1(.,2), halign(center)
putdocx table tabla1(.,3), halign(center)
putdocx table tabla1(.,4), halign(center)
putdocx table tabla1(.,5), halign(center)

putdocx table tabla1(2/7,.), border(bottom, single, "E6E6E6")
putdocx table tabla1(7,.), border(bottom, single, black)

* Anchos aproximados
putdocx table tabla1(.,1), width(28%)
putdocx table tabla1(.,2), width(18%)
putdocx table tabla1(.,3), width(18%)
putdocx table tabla1(.,4), width(18%)
putdocx table tabla1(.,5), width(18%)

* Espacio antes de notas
putdocx paragraph
putdocx text ("")

* Notas
putdocx paragraph
putdocx text ("Notas: "), bold
putdocx text ("Cada celda en las columnas ""Con acceso"", ""Sin acceso"" y ""Total"" reporta la media de la variable; la desviación estándar aparece entre paréntesis y el número de observaciones entre corchetes. ")

putdocx paragraph
putdocx text ("En las variables binarias (Apoyo al régimen, Ve TV de Kuran, Mujer y Urbano), la media puede interpretarse como una proporción. ")

putdocx paragraph
putdocx text ("La columna ""Diferencia"" reporta la diferencia de medias entre hogares con acceso y sin acceso a la señal, es decir, media(Z=1) − media(Z=0). Entre corchetes se reporta el p-valor del test t de diferencia de medias. ")

putdocx paragraph
putdocx text ("* p<0.10, ** p<0.05, *** p<0.01."), italic

putdocx save "output/tabla1_descriptivas_valmoria.docx", replace
restore


****************************************************
* 5. Graficos de barras: media de D por Z
****************************************************
graph bar (mean) D, over(Z, relabel(1 "Sin acceso" 2 "Con acceso") ///
    label(labsize(medsmall))) ///
    bar(1, color(navy*0.85) lcolor(navy)) ///
    blabel(bar, format(%4.2f) position(outside) size(medsmall) color(black)) ///
    ylabel(0(.2)1, format(%3.1f) labsize(small) angle(0) grid glcolor(gs13)) ///
    yscale(range(0 1.05)) ///
    ytitle("Proporción que ve TV de Kuran", size(medsmall)) ///
    title("Exposición efectiva por acceso a la señal", ///
          size(medium) color(black)) ///
    subtitle("Media de D según acceso técnico a la señal", ///
             size(small) color(gs6)) ///
    legend(off) ///
    graphregion(color(white) margin(medium)) ///
    plotregion(color(white) margin(medium)) ///
    name(g_D_Z, replace)

graph export "output/barra_media_D_por_Z.png", replace width(2400)

****************************************************
* 6. Graficos de barras: media de Y por Z
****************************************************
graph bar (mean) Y, over(Z, relabel(1 "Sin acceso" 2 "Con acceso") ///
    label(labsize(medsmall))) ///
    bar(1, color(maroon*0.85) lcolor(maroon)) ///
    blabel(bar, format(%4.2f) position(outside) size(medsmall) color(black)) ///
    ylabel(0(.2)1, format(%3.1f) labsize(small) angle(0) grid glcolor(gs13)) ///
    yscale(range(0 1.05)) ///
    ytitle("Proporción que apoya al régimen", size(medsmall)) ///
    title("Apoyo al régimen por acceso a la señal", ///
          size(medium) color(black)) ///
    subtitle("Media de Y según acceso técnico a la señal", ///
             size(small) color(gs6)) ///
    legend(off) ///
    graphregion(color(white) margin(medium)) ///
    plotregion(color(white) margin(medium)) ///
    name(g_Y_Z, replace)

graph export "output/barra_media_Y_por_Z.png", replace width(2400)

****************************************************
* Primera etapa, MCO y 2SLS
****************************************************

****************************************************
* 7.1 Primera etapa
****************************************************
reg D Z age female educ urban, vce(robust)

scalar b_fs  = _b[Z]
scalar se_fs = _se[Z]
scalar t_fs  = _b[Z]/_se[Z]
scalar p_fs  = 2*ttail(e(df_r), abs(_b[Z]/_se[Z]))
scalar n_fs  = e(N)
scalar r2_fs = e(r2)

test Z
scalar F_fs = r(F)

local stars_fs ""
if scalar(p_fs) < 0.10 local stars_fs "*"
if scalar(p_fs) < 0.05 local stars_fs "**"
if scalar(p_fs) < 0.01 local stars_fs "***"

local coef_fs = string(scalar(b_fs), "%9.4f") + "`stars_fs'"
local se1_fs  = "(" + string(scalar(se_fs), "%9.4f") + ")"

****************************************************
* 7.2 MCO
****************************************************
reg Y D age female educ urban, vce(robust)

scalar b_ols  = _b[D]
scalar se_ols = _se[D]
scalar t_ols  = _b[D]/_se[D]
scalar p_ols  = 2*ttail(e(df_r), abs(_b[D]/_se[D]))
scalar n_ols  = e(N)
scalar r2_ols = e(r2)

local stars_ols ""
if scalar(p_ols) < 0.10 local stars_ols "*"
if scalar(p_ols) < 0.05 local stars_ols "**"
if scalar(p_ols) < 0.01 local stars_ols "***"

local coef_ols = string(scalar(b_ols), "%9.4f") + "`stars_ols'"
local se1_ols  = "(" + string(scalar(se_ols), "%9.4f") + ")"

****************************************************
* 7.3 2SLS
****************************************************
ivregress 2sls Y age female educ urban (D = Z), vce(robust)

scalar b_iv  = _b[D]
scalar se_iv = _se[D]
scalar z_iv  = _b[D]/_se[D]
scalar p_iv  = 2*normal(-abs(_b[D]/_se[D]))
scalar n_iv  = e(N)

local stars_iv ""
if scalar(p_iv) < 0.10 local stars_iv "*"
if scalar(p_iv) < 0.05 local stars_iv "**"
if scalar(p_iv) < 0.01 local stars_iv "***"

local coef_iv = string(scalar(b_iv), "%9.4f") + "`stars_iv'"
local se1_iv  = "(" + string(scalar(se_iv), "%9.4f") + ")"


****************************************************
* 7.5 Exportar tabla / Hecho por chatgpt para exportar tabla lista para texto
****************************************************
putdocx clear
putdocx begin, pagesize(letter) font("Times New Roman", 11)

* Título
putdocx paragraph, halign(center)
putdocx text ("Tabla 2. Efecto de la exposición a TV extranjera sobre el apoyo al régimen"), ///
    bold font("Times New Roman", 12)

putdocx paragraph, halign(center)
putdocx text ("Primera etapa, MCO y 2SLS"), italic font("Times New Roman", 11)

putdocx paragraph
putdocx text ("")

* Tabla principal
* Filas:
* 1 encabezado
* 2 variable dependiente
* 3 Z
* 4 se de Z
* 5 D
* 6 se de D
* 7 Controles
* 8 Observaciones
* 9 R-cuadrado
* 10 F de primera etapa
putdocx table tabla_iv = (10,4), width(100%) layout(autofitcontents)

* Encabezados
putdocx table tabla_iv(1,1) = ("")
putdocx table tabla_iv(1,2) = ("(1) Primera etapa")
putdocx table tabla_iv(1,3) = ("(2) MCO")
putdocx table tabla_iv(1,4) = ("(3) 2SLS")

putdocx table tabla_iv(1,.), bold halign(center) shading("D9EAF7")
putdocx table tabla_iv(1,.), border(top, single, black) ///
                              border(bottom, single, black)

* Variable dependiente
putdocx table tabla_iv(2,1) = ("Variable dependiente")
putdocx table tabla_iv(2,2) = ("D")
putdocx table tabla_iv(2,3) = ("Y")
putdocx table tabla_iv(2,4) = ("Y")

* Coeficiente de Z
putdocx table tabla_iv(3,1) = ("Acceso a la señal (Z)")
putdocx table tabla_iv(3,2) = ("`coef_fs'")
putdocx table tabla_iv(3,3) = ("")
putdocx table tabla_iv(3,4) = ("")

* EE de Z
putdocx table tabla_iv(4,1) = ("")
putdocx table tabla_iv(4,2) = ("`se1_fs'")
putdocx table tabla_iv(4,3) = ("")
putdocx table tabla_iv(4,4) = ("")

* Coeficiente de D
putdocx table tabla_iv(5,1) = ("Ve TV de Kuran (D)")
putdocx table tabla_iv(5,2) = ("")
putdocx table tabla_iv(5,3) = ("`coef_ols'")
putdocx table tabla_iv(5,4) = ("`coef_iv'")

* EE de D
putdocx table tabla_iv(6,1) = ("")
putdocx table tabla_iv(6,2) = ("")
putdocx table tabla_iv(6,3) = ("`se1_ols'")
putdocx table tabla_iv(6,4) = ("`se1_iv'")

* Controles
putdocx table tabla_iv(7,1) = ("Controles demográficos")
putdocx table tabla_iv(7,2) = ("Sí")
putdocx table tabla_iv(7,3) = ("Sí")
putdocx table tabla_iv(7,4) = ("Sí")

* N
putdocx table tabla_iv(8,1) = ("Observaciones")
putdocx table tabla_iv(8,2) = (string(scalar(n_fs),  "%9.0f"))
putdocx table tabla_iv(8,3) = (string(scalar(n_ols), "%9.0f"))
putdocx table tabla_iv(8,4) = (string(scalar(n_iv),  "%9.0f"))

* R2
putdocx table tabla_iv(9,1) = ("R-cuadrado")
putdocx table tabla_iv(9,2) = (string(scalar(r2_fs),  "%9.4f"))
putdocx table tabla_iv(9,3) = (string(scalar(r2_ols), "%9.4f"))
putdocx table tabla_iv(9,4) = (".")

* F primera etapa
putdocx table tabla_iv(10,1) = ("F del instrumento excluido")
putdocx table tabla_iv(10,2) = (string(scalar(F_fs), "%9.4f"))
putdocx table tabla_iv(10,3) = ("")
putdocx table tabla_iv(10,4) = (string(scalar(F_fs), "%9.4f"))

* Formato general
putdocx table tabla_iv(.,1), halign(left)
putdocx table tabla_iv(.,2), halign(center)
putdocx table tabla_iv(.,3), halign(center)
putdocx table tabla_iv(.,4), halign(center)

putdocx table tabla_iv(2/10,.), border(bottom, single, "E6E6E6")
putdocx table tabla_iv(10,.), border(bottom, single, black)

* Anchos
putdocx table tabla_iv(.,1), width(36%)
putdocx table tabla_iv(.,2), width(21%)
putdocx table tabla_iv(.,3), width(21%)
putdocx table tabla_iv(.,4), width(22%)

****************************************************
* 7.6 Notas //Hecho por chatgpt para colocar notas en el texto 
****************************************************
putdocx paragraph
putdocx text ("")

putdocx paragraph
putdocx text ("Notas: "), bold
putdocx text ("La columna (1) reporta la primera etapa, donde la variable dependiente es D (ver TV de Kuran) y el regresor de interés es Z (acceso técnico a la señal). La columna (2) reporta la estimación por MCO del apoyo al régimen Y sobre D. La columna (3) reporta la estimación por 2SLS instrumentando D con Z. En todas las especificaciones se incluyen como controles edad, mujer, educación y urbano. Los errores estándar robustos se reportan entre paréntesis. ")

putdocx paragraph
putdocx text ("El estadístico F reportado corresponde a la prueba de exclusión del instrumento en la primera etapa. "), italic

putdocx paragraph
putdocx text ("* p<0.10, ** p<0.05, *** p<0.01."), italic

putdocx save "output/tabla2_iv_journal_valmoria.docx", replace

display "Listo. Se creó:"
display "output/tabla2_iv_journal_valmoria.docx"
